package com.myboost

import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.ActivityInfo
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*

val Bg = Color(0xFF080A12)
val CardC = Color(0xFF151A28)
val Red = Color(0xFFFF3158)
val Cyan = Color(0xFF43D9FF)
val Orange = Color(0xFFFFB454)
val Green = Color(0xFF42E6A4)
val Muted = Color(0xFF9AA7BD)

class MainActivity : ComponentActivity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        setContent { App() }
    }
}

@Composable fun App() {
    var tab by remember { mutableStateOf(0) }
    Row(Modifier.fillMaxSize().background(Bg)) {
        Column(Modifier.width(164.dp).fillMaxHeight().background(Color(0xFF101522)).padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Text("MYBOOST", color = Red, fontWeight = FontWeight.Black, fontSize = 26.sp)
            Text("GAME CONTROL", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            listOf("⚡  DASHBOARD", "🎮  GAME LIBRARY", "⚙  SETTINGS").forEachIndexed { i, t ->
                Text(t, color = if (tab == i) Color.White else Muted, fontWeight = FontWeight.Bold, fontSize = 12.sp,
                    modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                        .background(if (tab == i) Red.copy(.20f) else Color.Transparent)
                        .border(if (tab == i) 1.dp else 0.dp, if (tab == i) Red.copy(.65f) else Color.Transparent, RoundedCornerShape(12.dp)
                        ).clickable { tab = i }.padding(12.dp))
            }
            Spacer(Modifier.weight(1f))
            Text("PERFORMANCE HUD", color = Cyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Text("Landscape mode", color = Muted, fontSize = 10.sp)
        }
        Box(Modifier.weight(1f).fillMaxHeight().padding(18.dp)) {
            when (tab) { 0 -> Dash(); 1 -> Games(); else -> Setelan() }
        }
    }
}

@Composable fun RowScope.StatGauge(name: String, label: String, p: Float, col: Color) {
    Column(Modifier.weight(1f).clip(RoundedCornerShape(16.dp)).background(CardC).padding(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(7.dp)) {
        Box(contentAlignment = Alignment.Center) {
            CircularProgressIndicator(progress = p.coerceIn(0f, 1f), color = col,
                trackColor = Color(0xFF30384B), strokeWidth = 7.dp, modifier = Modifier.size(76.dp)
            )
            Text(label, color = Color.White, fontWeight = FontWeight.Black, fontSize = 15.sp)
        }
        Text(name, color = col, fontWeight = FontWeight.Bold, fontSize = 11.sp)
    }
}

@Composable fun GBtn(t: String, col: Color = Red, onClick: () -> Unit) =
    Button(onClick, colors = ButtonDefaults.buttonColors(containerColor = col),
        shape = RoundedCornerShape(10.dp), contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)) {
        Text(t, fontWeight = FontWeight.Bold, fontSize = 12.sp)
    }

@Composable fun Dash() {
    val c = LocalContext.current
    val scope = rememberCoroutineScope()
    var s by remember { mutableStateOf(Stats.read(c)) }
    var msg by remember { mutableStateOf("MONITORING READY") }
    LaunchedEffect(Unit) { while (true) { s = Stats.read(c); delay(1200) } }
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("BOOST CENTER", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Black)
                Text("Realtime device status • Gaming tools", color = Muted, fontSize = 11.sp)
            }
            Text("● SYSTEM ONLINE", color = Green, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatGauge("CPU • ${"%.2f".format(s.ghz)} GHz", "${s.cpu}%", s.cpu / 100f, Red)
            StatGauge("MEMORY", "${s.ram}%", s.ram / 100f, Cyan)
            StatGauge("TEMPERATURE", "${s.tempC}°C", s.tempC / 60f, Orange)
            StatGauge("BATTERY", "${s.bat}%", s.bat / 100f, Green)
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            GBtn("⚡ CLEAN BACKGROUND", Red) {
                scope.launch(Dispatchers.IO) {
                    val freed = Stats.boost(c)
                    withContext(Dispatchers.Main) { msg = "Cleanup request complete • approx. $freed MB freed" }
                }
            }
            GBtn("▶ START GAME PANEL", Color(0xFF167B78)) {
                ContextCompat.startForegroundService(c, Intent(c, BoostService::class.java)); msg = "Game Panel service started"
            }
            GBtn("■ STOP PANEL", Color(0xFF30384B)) { c.stopService(Intent(c, BoostService::class.java)); msg = "Game Panel service stopped" }
            Text(msg, color = Cyan, fontWeight = FontWeight.Bold, fontSize = 10.sp, modifier = Modifier.weight(1f))
        }
        Text("CPU readings are monitoring only; Android/device firmware controls actual CPU performance.", color = Muted, fontSize = 10.sp)
    }
}

@Composable fun Games() {
    val c = LocalContext.current
    val pm = c.packageManager
    val apps = remember { pm.getInstalledApplications(0).filter {
        pm.getLaunchIntentForPackage(it.packageName) != null && it.packageName != c.packageName
    }.sortedBy { pm.getApplicationLabel(it).toString().lowercase() }
    val selected = remember { mutableStateListOf<String>().apply { addAll(Prefs.games(c)) } }
    var search by remember { mutableStateOf("") }
    LaunchedEffect(Unit) {
        if (!Prefs.seeded(c)) {
            apps.filter { it.category == ApplicationInfo.CATEGORY_GAME || (it.flags and ApplicationInfo.FLAG_IS_GAME) != 0 }
                .forEach { if (it.packageName !in selected) selected += it.packageName; Prefs.setGame(c, it.packageName, true) }
            Prefs.setSeeded(c)
        }
    }
    Column(Modifier.fillMaxSize()) {
        Text("GAME LIBRARY", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black)
        Text("Pilih game atau aplikasi yang memicu panel overlay otomatis.", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(bottom = 8.dp))
        OutlinedTextField(search, { search = it }, label = { Text("Cari aplikasi") }, singleLine = true,
            modifier = Modifier.fillMaxWidth(), colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = Color.White, unfocusedTextColor = Color.White, focusedBorderColor = Red,
                unfocusedBorderColor = Muted, focusedLabelColor = Red, unfocusedLabelColor = Muted))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(top = 8.dp)) {
            items(apps.filter { pm.getApplicationLabel(it).toString().contains(search, ignoreCase = true) }) { app ->
                val on = app.packageName in selected
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(CardC)
                    .padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(pm.getApplicationLabel(app).toString(), color = Color.White, modifier = Modifier.weight(1f), fontSize = 13.sp)
                    Text(if (on) "PANEL ENABLED" else "ADD TO PANEL", color = if (on) Green else Muted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    Switch(on, { v ->
                        if (v && app.packageName !in selected) selected.add(app.packageName)
                        if (!v) selected.remove(app.packageName)
                        Prefs.setGame(c, app.packageName, v)
                    }, colors = SwitchDefaults.colors(checkedTrackColor = Red))
                }
            }
        }
    }
}

@Composable fun Setelan() {
    val c = LocalContext.current
    fun open(action: String, packageUri: Boolean = false) {
        c.startActivity(Intent(action).apply { if (packageUri) data = Uri.parse("package:${c.packageName}") })
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        Text("SYSTEM & INPUT", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black)
        Text("Setup izin agar panel dapat muncul di atas game dan membaca tombol.", color = Muted, fontSize = 11.sp)
        GBtn("1  •  Overlay permission", Red) { open(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, true) }
        GBtn("2  •  Usage access (deteksi game)", Color(0xFF242D42)) { open(Settings.ACTION_USAGE_ACCESS_SETTINGS) }
        GBtn("3  •  Accessibility / volume trigger", Color(0xFF242D42)) { open(Settings.ACTION_ACCESSIBILITY_SETTINGS) }
        GBtn("4  •  Do Not Disturb permission", Color(0xFF242D42)) { open(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS) }
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(CardC).padding(12.dp)) {
            Text("QUICK PAUSE INPUT", color = Cyan, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Text("Volume Up + Volume Down bersama • Gamepad L2 + R2 • tombol Start", color = Color.White, fontSize = 11.sp)
            Text("Pause overlay dapat menutupi layar game; tidak semua game mendukung pause eksternal.", color = Muted, fontSize = 10.sp)
        }
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(CardC).padding(12.dp)) {
            Text("PERFORMANCE", color = Cyan, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Text("MyBoost memantau CPU/RAM/suhu/baterai dan menjalankan cleanup terbatas. Pengaturan clock/voltase CPU dikendalikan Android atau firmware perangkat, bukan aplikasi ini.", color = Color.White, fontSize = 11.sp)
        }
    }
}
