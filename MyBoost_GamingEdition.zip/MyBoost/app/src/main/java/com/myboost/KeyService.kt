package com.myboost

import android.accessibilityservice.AccessibilityService
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent

/** Tangkap tombol saat game aktif: Vol+ & Vol- bersamaan, atau trigger gamepad L2+R2 / Start => Jeda. */
class KeyService : AccessibilityService() {
    private val down = mutableSetOf<Int>()
    override fun onKeyEvent(e: KeyEvent): Boolean {
        if (BoostService.game == null) return false
        if (e.action == KeyEvent.ACTION_UP) { down.remove(e.keyCode); return false }
        down += e.keyCode
        val combo = (KeyEvent.KEYCODE_VOLUME_UP in down && KeyEvent.KEYCODE_VOLUME_DOWN in down) ||
            (KeyEvent.KEYCODE_BUTTON_L2 in down && KeyEvent.KEYCODE_BUTTON_R2 in down) ||
            e.keyCode == KeyEvent.KEYCODE_BUTTON_START
        if (combo && e.repeatCount == 0) { down.clear(); BoostService.inst?.togglePause(); return true }
        return false
    }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
}
