package com.myboost

import android.app.*
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.os.*
import android.view.*
import android.widget.*

class BoostService : Service() {
    companion object { var inst: BoostService? = null; var game: String? = null }

    private lateinit var wm: WindowManager
    private val h = Handler(Looper.getMainLooper())
    private var handle: View? = null; private var panel: View? = null; private var pauseV: View? = null
    private var info: TextView? = null; private var paused = false
    private var cur: String? = null; private var last = System.currentTimeMillis() - 3_600_000
    private val RED = 0xFFFF2D55.toInt(); private val CYAN = 0xFF00E5FF.toInt()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate(); inst = this; wm = getSystemService(WindowManager::class.java)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("b", "MyBoost", NotificationManager.IMPORTANCE_LOW))
        startForeground(1, Notification.Builder(this, "b").setContentTitle("MyBoost aktif – menunggu game")
            .setSmallIcon(android.R.drawable.ic_media_play).build())
        h.post(tick)
    }

    override fun onDestroy() { exitGame(); inst = null; h.removeCallbacksAndMessages(null); super.onDestroy() }

    private val tick = object : Runnable {
        override fun run() {
            poll()
            val g = cur?.takeIf { it in Prefs.games(this@BoostService) }
            if (g != null && game == null) enterGame(g) else if (g == null && game != null) exitGame()
            info?.let { val s = Stats.read(this@BoostService)
                it.text = "CPU ${s.cpu}%  ${"%.1f".format(s.ghz)}GHz\nRAM ${s.ram}%\nSUHU ${s.tempC}°C   BAT ${s.bat}%" }
            h.postDelayed(this, 1500)
        }
    }

    private fun poll() {
        val um = getSystemService(UsageStatsManager::class.java)
        val ev = um.queryEvents(last, System.currentTimeMillis()); val e = UsageEvents.Event()
        while (ev.hasNextEvent()) { ev.getNextEvent(e); if (e.eventType == UsageEvents.Event.ACTIVITY_RESUMED) cur = e.packageName }
        last = System.currentTimeMillis() - 1000
    }

    private fun bg(col: Int, r: Int) = GradientDrawable().apply { setColor(col); cornerRadius = dp(r).toFloat(); setStroke(dp(1), RED) }
    private fun btn(label: String, col: Int, click: () -> Unit) = TextView(this).apply {
        text = label; setTextColor(Color.WHITE); textSize = 12f; typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER; setPadding(dp(14), dp(8), dp(14), dp(8)); background = bg(col, 8)
        setOnClickListener { click() }
    }
    private fun lp(w: Int, hh: Int, g: Int, x: Int = 0, y: Int = 0) = WindowManager.LayoutParams(w, hh,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
        PixelFormat.TRANSLUCENT).also { it.gravity = g; it.x = x; it.y = y }
    private fun rm(v: View?) { try { if (v != null) wm.removeView(v) } catch (_: Exception) {} }

    private fun enterGame(g: String) {
        game = g; Stats.dnd(this, true)
        handle = btn("⚡", 0xCC000000.toInt()) { togglePanel() }
        wm.addView(handle, lp(-2, -2, Gravity.TOP or Gravity.START, 0, dp(80)))
    }

    private fun exitGame() {
        if (paused) togglePause()
        rm(panel); rm(handle); panel = null; handle = null; info = null
        if (game != null) Stats.dnd(this, false); game = null
    }

    private fun togglePanel() {
        if (panel != null) { rm(panel); panel = null; info = null; return }
        info = TextView(this).apply { setTextColor(CYAN); textSize = 13f; typeface = Typeface.MONOSPACE }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(btn("🚀 BOOST", RED) {
                Thread { val mb = Stats.boost(this@BoostService)
                    h.post { Toast.makeText(this@BoostService, "Bebas $mb MB RAM", Toast.LENGTH_SHORT).show() } }.start() })
            addView(Space(this@BoostService), LinearLayout.LayoutParams(dp(8), 1))
            addView(btn("⏸ JEDA", 0xFF333344.toInt()) { togglePause() })
        }
        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(12))
            background = bg(0xEE0A0A0F.toInt(), 14)
            addView(TextView(context).apply { text = "MY BOOST"; setTextColor(RED); typeface = Typeface.DEFAULT_BOLD })
            addView(info); addView(row)
        }
        wm.addView(panel, lp(-2, -2, Gravity.TOP or Gravity.START, dp(56), dp(40)))
    }

    fun togglePause() {
        if (game == null) return; paused = !paused
        getSystemService(AudioManager::class.java).adjustStreamVolume(AudioManager.STREAM_MUSIC,
            if (paused) AudioManager.ADJUST_MUTE else AudioManager.ADJUST_UNMUTE, 0)
        if (paused) {
            pauseV = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setBackgroundColor(0xE6000000.toInt())
                addView(TextView(context).apply { text = "⏸  GAME DIJEDA"; setTextColor(RED); textSize = 28f
                    typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; setPadding(0, 0, 0, dp(16)) })
                addView(btn("▶ LANJUTKAN", RED) { togglePause() })
            }
            wm.addView(pauseV, lp(-1, -1, Gravity.CENTER))
        } else { rm(pauseV); pauseV = null }
    }
}
