package com.myboost

import android.app.ActivityManager
import android.content.*
import android.content.pm.ApplicationInfo
import android.os.BatteryManager
import android.app.NotificationManager
import java.io.File

data class Snap(val cpu: Int, val ghz: Float, val ram: Int, val tempC: Float, val bat: Int)

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("myboost", 0)
    fun games(c: Context): Set<String> = sp(c).getStringSet("games", emptySet())!!
    fun setGame(c: Context, p: String, on: Boolean) {
        val s = games(c).toMutableSet(); if (on) s += p else s -= p
        sp(c).edit().putStringSet("games", s).apply()
    }
    fun root(c: Context) = sp(c).getBoolean("root", false)
    fun setRoot(c: Context, v: Boolean) = sp(c).edit().putBoolean("root", v).apply()
    fun seeded(c: Context) = sp(c).getBoolean("seeded", false)
    fun setSeeded(c: Context) = sp(c).edit().putBoolean("seeded", true).apply()
}

object Stats {
    private fun rd(p: String) = try { File(p).readText().trim().toLongOrNull() } catch (e: Exception) { null }

    fun read(c: Context): Snap {
        var cur = 0L; var max = 0L; var n = 0
        for (i in 0 until Runtime.getRuntime().availableProcessors()) {
            val b = "/sys/devices/system/cpu/cpu$i/cpufreq/"
            val f = rd(b + "scaling_cur_freq") ?: continue
            val m = rd(b + "cpuinfo_max_freq") ?: continue
            cur += f; max += m; n++
        }
        val mi = ActivityManager.MemoryInfo()
        c.getSystemService(ActivityManager::class.java).getMemoryInfo(mi)
        val bi = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        return Snap(
            if (max > 0) (cur * 100 / max).toInt() else 0,
            if (n > 0) cur / n / 1_000_000f else 0f,
            ((mi.totalMem - mi.availMem) * 100 / mi.totalMem).toInt(),
            (bi?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f,
            bi?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0
        )
    }

    /** Tutup app background (kecuali game & MyBoost). Return MB RAM yang dibebaskan. */
    fun boost(c: Context): Int {
        val am = c.getSystemService(ActivityManager::class.java)
        val mi = ActivityManager.MemoryInfo(); am.getMemoryInfo(mi); val before = mi.availMem
        val games = Prefs.games(c)
        c.packageManager.getInstalledApplications(0)
            .filter { it.packageName != c.packageName && it.packageName !in games && (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 }
            .forEach { am.killBackgroundProcesses(it.packageName) }
        Thread.sleep(400); am.getMemoryInfo(mi)
        return ((mi.availMem - before) / 1048576).toInt().coerceAtLeast(0)
    }

    fun dnd(c: Context, on: Boolean) {
        val nm = c.getSystemService(NotificationManager::class.java)
        if (nm.isNotificationPolicyAccessGranted)
            nm.setInterruptionFilter(if (on) NotificationManager.INTERRUPTION_FILTER_PRIORITY else NotificationManager.INTERRUPTION_FILTER_ALL)
    }
}
